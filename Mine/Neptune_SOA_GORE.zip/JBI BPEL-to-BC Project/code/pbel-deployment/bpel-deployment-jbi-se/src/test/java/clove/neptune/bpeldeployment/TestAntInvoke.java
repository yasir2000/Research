/*
 * @(#)TestAntInvoke.java $Revision$ ($Date$)
 * 
 * Author: Yasir Karam
 *
 * Copyright (c) 2010 Yasir Karam 
 */
package clove.neptune.bpeldeployment;

/**
 * Test Ant Invoke
 *
 * @author Yasir Karam
 * @version $Revision$
 */
public class TestAntInvoke {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		org.apache.tools.ant.Main.main(args);
	}
}

/*
 * @(#)BPELDeployerLifeCycle.java $Revision$ ($Date$)
 * 
 * Author: Yasir Karam
 *
 * Copyright (c) 2010 Yasir Karam 
 */
package clove.neptune.bpeldeployment.jbi;

import java.io.StringReader;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.activation.DataHandler;
import javax.jbi.JBIException;
import javax.jbi.component.ComponentContext;
import javax.jbi.component.ComponentLifeCycle;
import javax.jbi.messaging.DeliveryChannel;
import javax.jbi.messaging.ExchangeStatus;
import javax.jbi.messaging.Fault;
import javax.jbi.messaging.InOut;
import javax.jbi.messaging.MessageExchange;
import javax.jbi.messaging.MessagingException;
import javax.jbi.messaging.NormalizedMessage;
import javax.jbi.servicedesc.ServiceEndpoint;
import javax.management.ObjectName;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;

import clove.neptune.bpeldeployment.util.Helper;

/**
 * BPEL Deployer Life Cycle
 *
 * @author Yasir Karam
 * @version $Revision$
 */
public class BPELDeployerLifeCycle implements ComponentLifeCycle {
    private Logger defaultLogger;
    private Logger componentLogger ;
	private ComponentContext componentContext;

    /** 
     * Delivery channel accept time out 
     */
    private final static long DC_ACCEPT_TIME_OUT = 3000; // milliseconds
    /** 
     * Receiver thread wait time before polling for messages after woke up 
     */
    private final static long RECEIVER_WAIT_TIME = 2000; // milliseconds
    /** 
     * Receiver thread wait time before force shutdown 
     */
    private final static long RECEIVER_SHUTDOWN_WAIT_TIME = 10; // seconds
    /** 
     * Synchronous send timeout 
     */
    //private static final long SEND_SYNC_TIMEOUT = 60000;
    /** 
     * NMR delivery channel 
     */
    private DeliveryChannel deliveryChannel;
    /** 
     * Receiver thread accept message exchange condition 
     */
    private AtomicBoolean canAccept = new AtomicBoolean(false);
    /** 
     * Receiver thread termination condition 
     */
    private AtomicBoolean canContinue = new AtomicBoolean(true);
    /** 
     * Receiver thread executor service 
     */
    private ExecutorService receiverThreadMgr;
    /** 
     * BPELDeployer Service implementation.  
     */
    private BPELDeployer bpelDeployer;
    /**
     *  BPELDeployer service description 
     */
    private BPELDeployerDescriptor bpelDeployerDescriptor;
    /** 
     * BPELDeployer ServiceEndpoint  
     */
    private ServiceEndpoint bpelDeployerServiceEndpoint;

    /**
     * Returns logger initialized from the component context or a default logger.
     * @return Logger
     */
    public final Logger getLogger() {
        // try init component logger
        if (componentLogger == null && componentContext != null) {
            try {
            	componentLogger = componentContext.getLogger(this.getClass().getName(), null);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        // init default logger if required
        if (componentLogger == null && defaultLogger == null) {
        	defaultLogger = Logger.getLogger(this.getClass().getName(), null);
        }
        return (componentLogger != null) ? componentLogger : defaultLogger;
    }

    /**
     * This is a default implementation which does not have any extension mbeans. extended
     * classes can return the mbean name for the extension mbeans if the component supports.
     * @return null to indicate no extension mbean.
	 * @see javax.jbi.component.ComponentLifeCycle#getExtensionMBeanName()
	 */
	public ObjectName getExtensionMBeanName() {
		return null;
	}

    /**
     * Initialize the component. 
     * @param context Component context
	 * @see javax.jbi.component.ComponentLifeCycle#init(javax.jbi.component.ComponentContext)
     * @throws javax.jbi.JBIException on error
	 */
	public void init(ComponentContext cc) throws JBIException {
		componentContext = cc;
		// 1. Open a delivery channel
		deliveryChannel = cc.getDeliveryChannel();
		
		// 2. Create message receiver thread
		initMessageExchangeReceiver();
		
		// 3. Initialize service providers
        // create Service implementation
        bpelDeployer = new BPELDeployerImpl(cc.getWorkspaceRoot());
        // generate jbi internal endpoint name for the service endpoint
        String bpelDeployerServiceEndpointName =
            BPELDeployerDescriptor.generateJBIInternalEndpointName(BPELDeployerDescriptor.ENDPOINT_NAME_PREFIX);
        // create BPELDeployerDescriptor that describes the service.
        bpelDeployerDescriptor =
            new BPELDeployerDescriptor(MessageExchange.Role.PROVIDER, bpelDeployerServiceEndpointName);

        getLogger().info(cc.getComponentName() + " initialized.");
	}

    /**
     * Shuts down the component.
	 * @see javax.jbi.component.ComponentLifeCycle#shutDown()
     * @throws javax.jbi.JBIException on error.
     */
	public void shutDown() throws JBIException {
		// 1. End message exchange receiver thread
		removeMessageExchangeReceiver();
		
		// 2. Close delivery channel.
        // closes delivery channel and remove the reference.
        try {
            if (deliveryChannel != null) {
                deliveryChannel.close();
            }
        } finally {
            deliveryChannel = null;
        }
		
		getLogger().info(getComponentContext().getComponentName() + "  shutdown.");
	}

	/** 
     * Starts the component.
	 * @see javax.jbi.component.ComponentLifeCycle#start()
     * @throws javax.jbi.JBIException on error.
	 */
	public void start() throws JBIException {
		// 1. Activate the Service Providers
        // activate BPELDeployer Service Endpoint
        QName serviceQName = bpelDeployerDescriptor.getServiceQName();
        String endpointName = bpelDeployerDescriptor.getEndpointName();
        bpelDeployerServiceEndpoint =
            getComponentContext().activateEndpoint(serviceQName, endpointName);
        getLogger().info("### Activated endpoint " + bpelDeployerServiceEndpoint);
        
        // 2. Start message exchange processing
        canAccept.set(true);  // start accepting the messages
        
        getLogger().info(getComponentContext().getComponentName() + " started.");
	}

    /**
     * Stops the component.
	 * @see javax.jbi.component.ComponentLifeCycle#stop()
     * @throws javax.jbi.JBIException on error.
     */
	public void stop() throws JBIException {
		// 1. Stop message exchange processing.
		canAccept.set(false); // stop accepting the messages

		// 2. Deactivate Service Providers.
        // deactivate BPELDeployer Service Endpoint
        getComponentContext().deactivateEndpoint(bpelDeployerServiceEndpoint);
        getLogger().info("## Deactivated endpoint " + bpelDeployerServiceEndpoint);

        getLogger().info(getComponentContext().getComponentName() + "  stopped.");
	}

	/**
	 * Returns the {@code componentContext} property value.
	 * @return the componentContext
	 */
	public ComponentContext getComponentContext() {
		return componentContext;
	}

	/**
     * Creates a message receiver thread as part of the component initialization.
     * This component wait to receive message exchange from its delivery channel
     * in this thread and then processes the received message exchange object.
     */
    private void initMessageExchangeReceiver() {
        receiverThreadMgr = Executors.newSingleThreadExecutor();
        receiverThreadMgr.execute(new Runnable() {
            public void run() {
                while (canContinue.get()) {  // continue running the thread
                    if (canAccept.get()) { // check for message exchange and process it
                        receiveAndProcessMessageExchange();
                    } else { // wait before polling for message exchange again.
                        try {
                        	Thread.sleep(RECEIVER_WAIT_TIME);
                        } catch (InterruptedException interruptException) {
                            // someone must have interrupted this thread. do nothing.
                        }
                    }
                }
            }
        });
    }

    /**
     * Removes the message receiver as part of the component shutdown process
     */
    private void removeMessageExchangeReceiver() {
    	canContinue.set(false);
        boolean terminated = false;
        try {
            receiverThreadMgr.shutdown();
            terminated = receiverThreadMgr.awaitTermination(RECEIVER_SHUTDOWN_WAIT_TIME, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // do nothing
        } finally {
            if (!terminated) {
                receiverThreadMgr.shutdownNow(); // Force shutdown the receiver thread.
            }
        }
    }

    /**
     * Pulls message exchange object from the delivery channel when
     * it is available and calls the appropriate message processing. 
     * In this case it calls the InOut message exchange processing method processInOutMessageExchange
     * to process InOut message exchange as a Service provider.
     */
    private void receiveAndProcessMessageExchange() {
        try {
            if (deliveryChannel != null ) {
                MessageExchange msgExchange = null;
                msgExchange = deliveryChannel.accept(DC_ACCEPT_TIME_OUT);
                if (msgExchange != null) {
                    processInOutMessageExchangeOnProvider(msgExchange);
                } else {
                    return; // delivery channel timeout occurred. do nothing.
                }
            } else {
                getLogger().info("### Delivery Channel Not Opened for receiving messages");
            }
        } catch (MessagingException e) {
        	getLogger().log(Level.SEVERE, e.getLocalizedMessage(), e);
        }
    }

    /**
     * Processes the message exchange as a InOut message exchange ServiceProvider. 
     * It retrieves In message and invokes the {@link BPELDeployer} service to
     * process the In message and then constructs the Out message or a fault message
     * based on the {@link BPELDeployer} service invocation results and then sends the message exchange
     * with the Out message or fault using the delivery channel's synchronous send.
     */
    private void processInOutMessageExchangeOnProvider(MessageExchange msgExchange) throws MessagingException {
        // Process InOut message exchange.
        InOut inOutExchange = (InOut) msgExchange;
        ExchangeStatus status = inOutExchange.getStatus();
        
        if (ExchangeStatus.ACTIVE.equals(status)) {
            // receive IN message.
            NormalizedMessage inMsg = inOutExchange.getInMessage();
            NormalizedMessage outMsg = null;
            Fault fault = null;
            Source inContent = null;
            Source faultContent = null;
            
            // process in message
            inContent = inMsg.getContent();
            // invoke the service operation
            try {
            	QName operation = msgExchange.getOperation();
            	if (operation != null) {
            		if (inMsg.getAttachmentNames() != null && !inMsg.getAttachmentNames().isEmpty()) {
            			String attachmentName = (String) inMsg.getAttachmentNames().iterator().next();
            			DataHandler dh  = inMsg.getAttachment(attachmentName);
                		Method m = BPELDeployer.class.getMethod(operation.getLocalPart(), DataHandler.class);
                		dh = (DataHandler) m.invoke(bpelDeployer, dh);
                		if (dh != null) {
                            outMsg = inOutExchange.createMessage();
                            outMsg.setContent(inContent);
                			outMsg.addAttachment(attachmentName, dh);
                		}
            		}
            	}
            } catch (Exception e) {
                // exception invoking the operation. so, set exception text as fault content.
                String faultText = Helper.getExceptionAsXmlText(e);
                faultContent = Helper.createDOMSource(new StringReader(faultText));
            }
            // set out or fault message
            if (outMsg != null) {
                // set the out message content.
                inOutExchange.setOutMessage(outMsg);
            } else if (faultContent != null) {
                fault = inOutExchange.createFault();
                fault.setContent(faultContent);
                inOutExchange.setFault(fault);
            }
            // send out or fault message.
            //deliveryChannel.sendSync(inOutExchange, SEND_SYNC_TIMEOUT);
            deliveryChannel.send(inOutExchange);
        } else if (ExchangeStatus.DONE.equals(status)) {
        	NormalizedMessage outMsg = inOutExchange.getOutMessage();
        	if (outMsg != null) {
    			String attachmentName = (String) outMsg.getAttachmentNames().iterator().next();
    			DataHandler dh  = outMsg.getAttachment(attachmentName);
    			if (dh != null) {
                	bpelDeployer.release(dh);
    			}
        	}
            getLogger().info(
            		"InOut Message Exchange Provider received DONE :" +
            		" END of service invocation");
        } else if (ExchangeStatus.ERROR.equals(status)) {
            Exception e = msgExchange.getError(); // get the error and print
            getLogger().log(
            		Level.SEVERE, 
            		"InOut Message Exchange Provider received Error: " + e.getMessage(),
            		e);
        }
    }
}
